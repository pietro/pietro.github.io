-- Deserializes a bit value received over multiple cycles and outputs a single
-- parallel value in one cycle.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity deserializer is
  generic (
    WIDTH : natural range 1 to 32);
  port (
    -- the clock
    clk : in std_logic;

    -- enable and serialize data input
    en_i : in std_logic;
    d_i  : in std_logic;

    -- enable and parallel data output. When a full word of data has been
    -- deserialized, en_o will pulse high for one cycle and the parallel data
    -- work will be output on d_o.
    en_o : out std_logic;
    d_o  : out std_logic_vector(WIDTH-1 downto 0));
end entity;

architecture arch of deserializer is
  -- a shift register holding recently receive input bits
  signal sr    : std_logic_vector(WIDTH-1 downto 0);
  -- counts the number of bits shifted into sr since the last output cycle
  signal count : natural range 0 to WIDTH-1 := 0;
begin

  process(clk, en_i, d_i)
    variable new_sr : std_logic_vector(WIDTH-1 downto 0);
  begin
    if clk = '1' and clk'event then
      -- assume an output isn't happening this cycle
      d_o  <= (others => '0');
      en_o <= '0';

      if en_i = '1' then
        -- shift in new input
        new_sr := d_i & sr(WIDTH-1 downto 1);
        sr <= new_sr;
        if count = WIDTH-1 then
          -- shift register is full. output the deserialized data
          en_o  <= '1';
          d_o   <= new_sr;
          count <= 0;
        else
          count <= count + 1;
        end if;
      end if;
    end if;
  end process;
end architecture;
