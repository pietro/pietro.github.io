-- An example of printing to stdout

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- These textio libs are needed for writing output. They will only work in simulation
use std.textio.all;
use ieee.std_logic_textio.all;

entity hello_world is
end entity;

architecture arch of hello_world is
  signal a_bit : std_logic := '1';
  signal multiple_bits : std_logic_vector(31 downto 0) := x"BEAF1001";
begin
  writer : process
    variable ln : line;
  begin
    -- 'output' is stdout. It's defined in std.textio.
    write(output, "Hello world!");

    -- You can build strings before writing them
    write(ln, string'("Hi")); -- Need a type cast to string here to
                              -- differentiate between multiple overloaded
                              -- write procedures

    write(ln, string'(". This is a bit "));
    write(ln, a_bit);
    write(ln, string'(", and this is multiple bits "));
    write(ln, multiple_bits);
    writeline(output, ln); -- outputs and clears ln

    write(ln, string'("and here's that value again in hex "));
    hwrite(ln, multiple_bits);
    writeline(output, ln);
    wait; -- Final wait to stop process from rerunning. Comment this out and
          -- see what happens.
  end process;
end architecture;
