library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity serdes_sim is
end entity;

architecture arch of serdes_sim is
  constant WORD_WIDTH : natural := 8;
  signal clk : std_logic := '0';

  -- inputs to the serializer
  -- initialize these to 0 so they are defined at the start of the simulation
  signal en_i : std_logic := '0';
  signal d_i  : std_logic_vector(WORD_WIDTH-1 downto 0) := (others => '0');

  -- intermediate signals that contain the serialized data
  signal serial_en : std_logic;
  signal serial_d  : std_logic;

  -- outputs of the deserializer
  signal en_o : std_logic;
  signal d_o  : std_logic_vector(WORD_WIDTH-1 downto 0);

  signal ser_rdy : std_logic;
begin

  -- Generate a clock signal that drives the simulation. In an FPGA, clocks
  -- are usually derived from an input to the FPGA. In simulation, we need to
  -- generate the clock ourselves.
  clk_gen : process
  begin
    clk <= '0';
    wait for 10 ns;
    clk <= '1';
    wait for 10 ns;
  end process;

  -- Instantiate the serializer and deserializer entities. They are connected to
  -- eachother by the serial_en and serial_d signals.

  ser : entity work.serializer
    generic map (
      WIDTH => WORD_WIDTH)
    port map (
      clk  => clk,
      en_i => en_i,
      d_i  => d_i,
      rdy  => ser_rdy,
      en_o => serial_en,
      d_o  => serial_d);

  des : entity work.deserializer
    generic map (
      WIDTH => WORD_WIDTH)
    port map (
      clk  => clk,
      en_i => serial_en,
      d_i  => serial_d,
      en_o => en_o,
      d_o  => d_o);

  -- drive the simulation by feeding input to the serializer
  p : process
  begin
    -- wait a few cycles before starting input
    wait until clk = '1' and clk'event;
    wait until clk = '1' and clk'event;
    wait until clk = '1' and clk'event;

    -- pass an input value
    en_i <= '1';
    d_i  <= "10110010";
    wait until clk = '1' and clk'event;
    en_i <= '0';
    wait until ser_rdy = '1'; -- wait until the serializer is ready for the
                              -- next input

    -- pass a second input value
    en_i <= '1';
    d_i  <= x"55"; -- can also use hex literals
    wait until clk = '1' and clk'event;
    en_i <= '0';
    wait until ser_rdy = '1';

    en_i <= '1';
    d_i  <= x"F0";
    wait until clk = '1' and clk'event;
    en_i <= '0';
    wait until ser_rdy = '1';

    en_i <= '1';
    d_i  <= "00110011";
    wait until clk = '1' and clk'event;
    en_i <= '0';
    wait until ser_rdy = '1';

    wait; -- wait at the end so process doesn't continue to run
  end process;

end architecture;
