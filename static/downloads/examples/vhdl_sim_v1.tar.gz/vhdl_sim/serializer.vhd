-- Serializes a parallel input value and outputs it over multiple cycles, one
-- bit at a time.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity serializer is
  generic (
    WIDTH : natural range 1 to 32);
  port (
    -- the clock
    clk : in std_logic;

    -- an enable and parallel data input to provide the word to serialize
    en_i : in std_logic;
    d_i  : in std_logic_vector(WIDTH-1 downto 0);

    -- a ready output that is high when the serializer will accept a data word
    -- in the next cycle
    rdy  : out std_logic;

    -- enable and serial data outputs
    en_o : out std_logic;
    d_o  : out std_logic);
end entity;

architecture arch of serializer is
  -- a shift register holding recently bits as they are shifted out
  signal sr    : std_logic_vector(WIDTH-1 downto 0);
  -- counts the number of bits remaining in sr that will be shifted out
  signal count : natural range 0 to WIDTH := 0;
begin

  -- signal when we can accept a new input
  rdy <= '1' when count = 0 else '0';

  process(clk, en_i, d_i)
  begin
    if clk = '1' and clk'event then
      if count = 0 then
        -- nothing to output
        d_o  <= '0';
        en_o <= '0';
        -- accept input
        if en_i = '1' then
          sr <= d_i;
          count <= WIDTH;
        end if;
      else
        -- shift a bit out
        en_o <= '1';
        d_o <= sr(0);
        sr <= '0' & sr(WIDTH-1 downto 1);
        count <= count - 1;
      end if;
    end if;
  end process;
end architecture;
